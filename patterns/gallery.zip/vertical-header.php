<?php
/**
 * Title: هدر عمودی سالنما
 * Slug: salenama-vertical-header
 * Description: هدر عمودی با منوی تمام صفحه، انیمیشن‌های پیشرفته GSAP و طراحی ریسپانسیو
 * Categories: salenama-headers
 * Keywords: هدر, منو, عمودی, سالنما, header, vertical, منوی تمام صفحه, animated
 * Viewport Width: 1200
 * Inserter: true
 * Block Types: core/template-part/header
 */

?>

<!-- wp:group {"tagName":"header","align":"full","className":"minimal-vertical-header fixed top-0 right-0 h-full w-[8.33%] z-[100] p-6 lg:p-12 transition-all duration-300 ease-in-out is-minimal-header","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"0","left":"0","right":"0"},"blockGap":"0"},"border":{"radius":{"topLeft":"8px","topRight":"8px","bottomLeft":"8px","bottomRight":"8px"}},"shadow":"var:preset|shadow|3D","elements":{"link":{"color":{"text":"var:preset|color|background"}}}},"textColor":"background","layout":{"type":"flex","orientation":"vertical","justifyContent":"center","verticalAlignment":"space-between"}} -->
<header class="wp-block-group alignfull minimal-vertical-header fixed top-0 right-0 h-full w-[8.33%] z-[100] p-6 lg:p-12 transition-all duration-300 ease-in-out is-minimal-header has-background-color has-text-color has-link-color" style="border-top-left-radius:8px;border-top-right-radius:8px;border-bottom-left-radius:8px;border-bottom-right-radius:8px;padding-top:var(--wp--preset--spacing--20);padding-right:0;padding-bottom:0;padding-left:0;box-shadow:var(--wp--preset--shadow--3-d)"><!-- wp:group {"style":{"shadow":"var:preset|shadow|none","spacing":{"padding":{"left":"0","right":"0","top":"0","bottom":"0"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"}},"backgroundColor":"transparent","layout":{"type":"constrained","justifyContent":"right"}} -->
<div class="wp-block-group has-transparent-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;box-shadow:var(--wp--preset--shadow--none)"><!-- wp:group {"className":"p-2 menu-toggle-area cursor-pointer","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"var:preset|spacing|20"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"},"shadow":"var:preset|shadow|none","layout":{"selfStretch":"fit","flexSize":null}},"backgroundColor":"transparent","layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group p-2 menu-toggle-area cursor-pointer has-transparent-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:var(--wp--preset--spacing--20);padding-bottom:0;padding-left:0;box-shadow:var(--wp--preset--shadow--none)"><!-- wp:html -->
<div class="menu-icon">  
<svg
    id="Layer_1"
    xmlns="http://www.w3.org/2000/svg"
    version="1.1"
    viewBox="0 0 73.7 73.7"
	class="svg-menu-icon"
  >
    <defs>
      <style>
        .st0 {
          fill: none;
          stroke: currentColor;
          stroke-miterlimit: 10;
          stroke-width: 1;
        }
        .st1 {
          fill: none;
          stroke: currentColor;
          stroke-miterlimit: 10;
          stroke-width: 1.5;
        }
      </style>
    </defs>
    <!-- خطوط منو -->
    <line class="st0" x1="59.53" y1="48.85" x2="14.17" y2="48.85" />
    <line class="st0" x1="59.53" y1="58.85" x2="14.17" y2="58.85" />
    <line class="st0" x1="59.53" y1="38.85" x2="14.17" y2="38.85" />
    <!-- فلش (برای انیمیشن رفت و برگشت) -->
    <polyline class="st1 arrow-path" points="12.5 15.15 36.82 37.17 61.2 15.11" />
    <!-- دایره دور آیکون -->
    <circle class="st0 circle-path" cx="36.85" cy="36.85" r="35.42" />
  </svg>
</div>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"logo-container w-full opacity-0 transition-opacity duration-300 absolute top-1/2 -translate-y-1/2","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"transparent","layout":{"type":"constrained"}} -->
<div class="wp-block-group logo-container w-full opacity-0 transition-opacity duration-300 absolute top-1/2 -translate-y-1/2 has-transparent-background-color has-background" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:site-logo {"className":"salnama-logo"} /-->

<!-- wp:site-title {"textAlign":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|text-secondary"}}}},"textColor":"text-secondary","fontSize":"small"} /--></div>
<!-- /wp:group -->

<!-- wp:group {"className":"action-buttons-container mt-auto w-full flex-grow-1","style":{"spacing":{"blockGap":"0","padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}},"layout":{"selfStretch":"fit","flexSize":null}},"backgroundColor":"transparent","layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch","verticalAlignment":"center","flexWrap":"nowrap"}} -->
<div class="wp-block-group action-buttons-container mt-auto w-full flex-grow-1 has-transparent-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"className":"action-icons space-y-4","style":{"border":{"bottom":{"color":"var:preset|color|brand-blue","width":"2px"}},"spacing":{"blockGap":"var:preset|spacing|20","padding":{"top":"0","bottom":"0","left":"0","right":"0"},"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}},"elements":{"link":{"color":{"text":"var:preset|color|background"}}}},"backgroundColor":"transparent","textColor":"background","layout":{"type":"flex","orientation":"horizontal","justifyContent":"center","verticalAlignment":"bottom","gap":"var(\u002d\u002dwp\u002d\u002dpreset\u002d\u002dspacing\u002d\u002d40)","flexWrap":"nowrap"}} -->
<div class="wp-block-group action-icons space-y-4 has-background-color has-transparent-background-color has-text-color has-background has-link-color" style="border-bottom-color:var(--wp--preset--color--brand-blue);border-bottom-width:2px;margin-top:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--20);padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:woocommerce/customer-account {"displayStyle":"icon_only","iconStyle":"line","iconClass":"wc-block-customer-account__account-icon","backgroundColor":"transparent"} /-->

<!-- wp:woocommerce/mini-cart /--></div>
<!-- /wp:group -->

<!-- wp:group {"className":"cta-button-wrapper","style":{"layout":{"selfStretch":"fit","flexSize":null}},"backgroundColor":"consult-cta","layout":{"type":"constrained"}} -->
<div class="wp-block-group cta-button-wrapper has-consult-cta-background-color has-background"><!-- wp:html -->
<div class="header-cta-container">
    <a class="cta-button" href="#" data-modal-trigger="header-contact">
        مشاوره
    </a>
</div>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></header>
<!-- /wp:group -->

<!-- wp:group {"className":"full-screen-menu-overlay fixed top-0 left-0 h-full w-full z-[90] opacity-0 pointer-events-none transition-opacity duration-300 ease-in-out bg-surface/95","style":{"elements":{"link":{"color":{"text":"var:preset|color|card-bg"}}}},"backgroundColor":"transparent","textColor":"card-bg","layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"center","orientation":"vertical"}} -->
<div class="wp-block-group full-screen-menu-overlay fixed top-0 left-0 h-full w-full z-[90] opacity-0 pointer-events-none transition-opacity duration-300 ease-in-out bg-surface/95 has-card-bg-color has-transparent-background-color has-text-color has-background has-link-color"><!-- wp:group {"tagName":"section","className":"full-screen-menu-group","style":{"spacing":{"padding":{"right":"0px","top":"3rem","left":"0px"}},"border":{"radius":{"topLeft":"30px","topRight":"30px","bottomLeft":"30px","bottomRight":"30px"}},"shadow":"var:preset|shadow|3D"},"backgroundColor":"text-secondary","layout":{"type":"constrained"}} -->
<section class="wp-block-group full-screen-menu-group has-text-secondary-background-color has-background" style="border-top-left-radius:30px;border-top-right-radius:30px;border-bottom-left-radius:30px;border-bottom-right-radius:30px;padding-top:3rem;padding-right:0px;padding-left:0px;box-shadow:var(--wp--preset--shadow--3-d)"><!-- wp:group {"className":"full-screen-menu-inner","style":{"border":{"radius":{"topLeft":"1px","topRight":"1px","bottomLeft":"1px","bottomRight":"1px"}},"spacing":{"padding":{"top":"0","bottom":"0"}}},"backgroundColor":"azure-web","layout":{"type":"constrained","contentSize":""}} -->
<div class="wp-block-group full-screen-menu-inner has-azure-web-background-color has-background" style="border-top-left-radius:1px;border-top-right-radius:1px;border-bottom-left-radius:1px;border-bottom-right-radius:1px;padding-top:0;padding-bottom:0"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"width":"80%"} -->
<div class="wp-block-column" style="flex-basis:80%"><!-- wp:group {"backgroundColor":"transparent","layout":{"type":"default"}} -->
<div class="wp-block-group has-transparent-background-color has-background"><!-- wp:woocommerce/accordion-group {"autoclose":true,"layout":{"type":"constrained","justifyContent":"right"}} -->
<div class="wp-block-woocommerce-accordion-group"><!-- wp:woocommerce/accordion-item -->
<div class="wp-block-woocommerce-accordion-item"><!-- wp:woocommerce/accordion-header {"icon":"caret","style":{"elements":{"link":{"color":{"text":"var:preset|color|text-primary"}}}},"textColor":"text-primary"} -->
<h3 class="wp-block-woocommerce-accordion-header has-text-primary-color has-text-color has-link-color has-text-primary-color has-text-color has-link-color accordion-item__heading"><button class="accordion-item__toggle"><span>تقویم رومیزی</span><span class="accordion-item__toggle-icon has-icon-caret" style="width:1.2em;height:1.2em"><svg width="1.2em" height="1.2em" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 14.5L16.5 9.5L7.5 9.5L12 14.5Z" fill="currentColor"></path></svg></span></button></h3>
<!-- /wp:woocommerce/accordion-header -->

<!-- wp:woocommerce/accordion-panel -->
<div class="wp-block-woocommerce-accordion-panel"><div class="accordion-content__wrapper"><!-- wp:paragraph -->
<p>اگر ابزار Git باز نمی‌شود و همان خطا را می‌دهد، معمولاً گزینه‌ی حذف (Remove Repository) در همان بخش وجود دارد.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>اگر حتی وارد بخش Git نمی‌شوید، باید از <strong>پشتیبانی هاست</strong> بخواهید پوشه‌ی <code>git</code> را دوباره بسازند یا تنظیمات Git را ریست کنند.</p>
<!-- /wp:paragraph --></div></div>
<!-- /wp:woocommerce/accordion-panel --></div>
<!-- /wp:woocommerce/accordion-item -->

<!-- wp:woocommerce/accordion-item -->
<div class="wp-block-woocommerce-accordion-item"><!-- wp:woocommerce/accordion-header {"icon":"chevron"} -->
<h3 class="wp-block-woocommerce-accordion-header accordion-item__heading"><button class="accordion-item__toggle"><span>تقویم دیواری </span><span class="accordion-item__toggle-icon has-icon-chevron" style="width:1.2em;height:1.2em"><svg width="1.2em" height="1.2em" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M18.0041 10.5547L11.9996 16.0134L5.99512 10.5547L7.00413 9.44482L11.9996 13.9862L16.9951 9.44483L18.0041 10.5547Z" fill="currentColor"></path></svg></span></button></h3>
<!-- /wp:woocommerce/accordion-header -->

<!-- wp:woocommerce/accordion-panel -->
<div class="wp-block-woocommerce-accordion-panel"><div class="accordion-content__wrapper"><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">تک برگ</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">چهار برگ</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">کوچک</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">بزرگ</a></div>
<!-- /wp:button -->

<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">A3</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:woocommerce/accordion-panel --></div>
<!-- /wp:woocommerce/accordion-item --></div>
<!-- /wp:woocommerce/accordion-group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"20%","style":{"border":{"left":{"color":"var:preset|color|text-primary"},"top":[],"right":[],"bottom":[]}}} -->
<div class="wp-block-column" style="border-left-color:var(--wp--preset--color--text-primary);flex-basis:20%"><!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>تماس با ما</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>درباره ما</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>حذف امنیت</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>لینک های مفید</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></section>
<!-- /wp:group --></div>
<!-- /wp:group -->